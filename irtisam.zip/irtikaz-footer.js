/* تذييل ارتكاز المشترك: أضِف سطر <script src="irtikaz-footer.js" defer></script> في الصفحة.
   يحاول قراءة الإعدادات من academy.irtikaz.workers.dev/footer-config.js، وإن تعذّر يستخدم الاحتياطي. */
(function () {
  'use strict';
  if (window.__irtikazFooterLoaded) return;
  window.__irtikazFooterLoaded = true;
  var BASE = 'https://academy.irtikaz.workers.dev/';
  var DEF = {
    note: 'أُنشئ بواسطة',
    links: [
      { name: 'أكاديمية ارتكاز', url: BASE, logo: '' },
      { name: 'استوديو ارتسام', url: 'https://irtisam.irtikaz.workers.dev/', logo: '' }
    ]
  };
  var done = false;
  function safe(u) { return typeof u === 'string' && /^https:\/\/[^\s"'<>]+$/i.test(u) ? u : ''; }
  function render(cfg) {
    if (done) return; done = true;
    try {
      cfg = cfg && cfg.links && cfg.links.length ? cfg : DEF;
      var host = document.createElement('div');
      host.setAttribute('data-irtikaz-footer', '');
      var root = host.attachShadow ? host.attachShadow({ mode: 'open' }) : host;
      var st = document.createElement('style');
      st.textContent =
        ':host{display:block;direction:rtl;text-align:center;font-family:inherit;color:inherit;padding:18px 16px 26px;margin-top:24px;border-top:1px solid rgba(128,128,128,.25)}' +
        '.n{font-size:.8rem;opacity:.75;margin:0 0 8px}' +
        '.r{display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:8px 18px}' +
        'a{display:inline-flex;align-items:center;gap:8px;color:inherit;text-decoration:none;font-weight:600;font-size:.95rem;padding:4px 6px;border-radius:8px}' +
        'a:hover,a:focus-visible{text-decoration:underline;outline:none;background:rgba(128,128,128,.12)}' +
        'img{width:26px;height:26px;object-fit:contain;border-radius:6px;background:#fff}';
      root.appendChild(st);
      var n = document.createElement('p'); n.className = 'n'; n.textContent = cfg.note || DEF.note; root.appendChild(n);
      var row = document.createElement('div'); row.className = 'r';
      cfg.links.forEach(function (l) {
        var u = safe(l.url); if (!u) return;
        var a = document.createElement('a'); a.href = u; a.target = '_blank'; a.rel = 'noopener';
        var lg = safe(l.logo);
        if (lg) { var im = document.createElement('img'); im.src = lg; im.alt = ''; im.onerror = function () { im.remove(); }; a.appendChild(im); }
        var t = document.createElement('span'); t.textContent = String(l.name || ''); a.appendChild(t);
        row.appendChild(a);
      });
      root.appendChild(row);
      if (!host.attachShadow) host.style.cssText = 'display:block;text-align:center;padding:18px 16px 26px;opacity:.85';
      document.body.appendChild(host);
    } catch (e) { /* التذييل اختياري ولا يجب أن يكسر الموقع */ }
  }
  function start() {
    var s = document.createElement('script');
    s.src = BASE + 'footer-config.js'; s.async = true;
    s.onload = function () { render(window.IRTIKAZ_FOOTER); };
    s.onerror = function () { render(DEF); };
    setTimeout(function () { render(DEF); }, 3500);
    document.head.appendChild(s);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
